/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Clases.Cita;
import Controladores.DCita;
import Controladores.MCompra;
import Validadores.Tiempo;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "CrearCita", urlPatterns = {"/crecita"})
public class CrearCita extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ArrayList<String> meses= new ArrayList(Arrays.asList("Enero","Febrero","Marzo","Abril",
                                                            "Mayo","Junio","Julio","Agosto",
                                                            "Septiembre","Octubre","Noviembre","Diciembre"));
        String anio= request.getParameter("anio");
        String mes= request.getParameter("mes");
        int numero=meses.indexOf(mes)+1;
        mes= numero<10?"0"+Integer.toString(numero):Integer.toString(numero); 
        String dia= request.getParameter("dia");
        dia= Integer.parseInt(dia)<10?"0"+dia:dia;
        String hora= request.getParameter("hora")+":00";
        String agendar= anio+"-"+mes+"-"+dia+" "+hora;
        String sucursal= request.getParameter("sucursales");
        boolean paso= false;
        String previo="";
        int dur=20;
        int durpre=0;
        String se="";
        int id_par=0;
        HashMap<String,ArrayList<Cita>> citas=  new DCita().getCitas(sucursal); 
            if( citas.get(sucursal).isEmpty()){
                paso=true;
            }   else    { 
                for(Cita cita : citas.get(sucursal)){
                    previo= cita.getDia_cit();
                    durpre= cita.getDur_cit();
                    paso= new Tiempo().isDisponible(agendar, previo, dur, durpre);
                    if(paso){
                        se= cita.getId_cita();
                        id_par= new MCompra().getEmpleado(se);
                        break;
                    }
                }
            }
        request.getSession().setAttribute("isDisponible", paso);
        request.getSession().setAttribute("pareja", id_par);
        out.print("Fecha Disponible: "+paso);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
