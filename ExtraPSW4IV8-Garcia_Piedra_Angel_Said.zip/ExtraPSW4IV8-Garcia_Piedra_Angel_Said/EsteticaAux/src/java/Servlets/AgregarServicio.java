/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Clases.Cliente;
import Clases.Compra;
import Clases.Servicio;
import Controladores.CServicios;
import Controladores.MClientes;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "AgregarServicio", urlPatterns = {"/addsrvice"})
public class AgregarServicio extends HttpServlet {
    
    //Instancia: /addsrvice

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public ArrayList<Compra> isNull(){
        ArrayList<Compra> carrito= new ArrayList<Compra>();
        return carrito;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String nom_ser= request.getParameter("nom_ser");
        String sucursal= request.getParameter("sucursales");
        Cliente cliente= new MClientes().getCliente(request.getSession().getAttribute("nombre").toString());
        Servicio servicio= new CServicios().getServicio(nom_ser);
        ArrayList<Compra> carrito= (ArrayList<Compra>)request.getSession().getAttribute("carrito")== null
                        ?isNull():(ArrayList<Compra>)request.getSession().getAttribute("carrito");
        carrito.add(new Compra(0,"",cliente.getId_cli(),0,servicio.getId_ser(),0));
        request.getSession().setAttribute("carrito", carrito);
        float costo= request.getSession().getAttribute("cos_total")==null?0:(float)request.getSession().getAttribute("cos_total");
        request.getSession().setAttribute("cos_total", servicio.getCos_ser()+costo);
        int duracion= request.getSession().getAttribute("dur_total")==null?0:(int)request.getSession().getAttribute("dur_total");
        request.getSession().setAttribute("cos_total", servicio.getDur_ser()+duracion);
        request.getSession().setAttribute("carrito", carrito);
        request.getRequestDispatcher("/Cita.jsp").forward(request, response);
        

                
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
