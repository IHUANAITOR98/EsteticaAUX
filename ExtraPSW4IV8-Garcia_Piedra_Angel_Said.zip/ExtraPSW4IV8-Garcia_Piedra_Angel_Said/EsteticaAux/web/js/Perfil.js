/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function cancelar(){
    
    if(window.confirm('Seguro que quiere cancelar su cita\n \n\
                    No se le será reembolsado su anticipo')){
        document.getElementById('eliminar').submit();
    }else{
        document.getElementById("eliminar").addEventListener("click", function(event){
            event.preventDefault()
        });
    }
}