-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: db_estaux
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cservicios`
--

DROP TABLE IF EXISTS `cservicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cservicios` (
  `id_ser` int unsigned NOT NULL AUTO_INCREMENT,
  `nom_ser` varchar(70) NOT NULL,
  `dur_ser` int NOT NULL,
  `cos_ser` float(6,2) NOT NULL,
  PRIMARY KEY (`id_ser`),
  UNIQUE KEY `nom_ser` (`nom_ser`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cservicios`
--

LOCK TABLES `cservicios` WRITE;
/*!40000 ALTER TABLE `cservicios` DISABLE KEYS */;
INSERT INTO `cservicios` VALUES (1,'Premium Makeup de dia',60,1400.00),(2,'Premium Makeup con aerografo',70,1650.00),(3,'Premium Makeup de noche',80,1750.00),(4,'Esmalte natural en manos',20,340.00),(5,'Esmalte natural en pies',20,350.00),(6,'Gel en manos',40,460.00),(7,'Gel en pies',45,480.00),(8,'Manicure para caballero',30,500.00),(9,'Manicure',45,500.00),(10,'Pedicure para caballero',65,520.00),(11,'Pedicure',65,520.00),(12,'Gel en manos con decoracion',60,580.00),(13,'Acrilico y gel en manos',60,580.00),(14,'Manicure gel',55,580.00),(15,'Pedicure gel',75,620.00),(16,'Gel en manos y pies',70,650.00),(17,'Manicure y pedicure para caballero',100,720.00),(18,'Manicure y pedicure',120,720.00),(19,'Estilizado de extensiones',35,140.00),(20,'Aplicacion de pestañas',20,210.00),(21,'Alaciado con plancha',50,490.00),(22,'Moldeado con secadora',50,490.00),(23,'Ondas surfer',60,490.00),(24,'Ondas vintage',60,490.00),(25,'Peinado Sencillo',45,530.00),(26,'Peinado recogido',60,640.00),(27,'Maquillaje de dia sin pestañas',50,800.00),(28,'Maquillaje de dia con pestañas',60,920.00),(29,'Alto peinado',60,930.00),(30,'Maquillaje de noche sin pestañas',50,990.00),(31,'Maquillaje de noche con pestañas',60,1160.00),(32,'Paquete de maquillaje de dia y Ondas',120,1150.00),(33,'Paquete de maquillaje de dia y peinado recogido',120,1350.00),(34,'Paquete de maquillaje de noche y Ondas',130,1380.00),(35,'Paquete de maquillaje de noche y peinado recogido',130,1600.00),(36,'Corte individual',30,490.00),(37,'Paquete 2 cortes',50,890.00),(38,'Paquete 3 cortes',70,1090.00),(39,'Paquete 4 cortes',70,1190.00),(40,'Tratamiento de hidratacion con Olaplex',30,390.00);
/*!40000 ALTER TABLE `cservicios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-14 18:58:25
