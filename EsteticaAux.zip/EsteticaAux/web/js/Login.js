/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function displayForm(){
    
    var tipo= document.getElementById('tipousu').value;
    
    if(tipo==="Cliente"){
        document.getElementById('Clientelog').style.display= 'initial';
        document.getElementById('Adminlog').style.display= 'none';
    } else {
        document.getElementById('Adminlog').style.display= 'initial';
        document.getElementById('Clientelog').style.display= 'none';
    }
}

