/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function displayForm(){
    
    var tipo= document.getElementById('tipousu').value;
    
    if(tipo==="Cliente"){
        document.getElementById('log_form_cl').style.display= 'initial';
        document.getElementById('log_form_ge').style.display= 'none';
    } else {
        document.getElementById('log_form_ge').style.display= 'initial';
        document.getElementById('log_form_cl').style.display= 'none';
    }
    
    console.log(tipo);
}

function checkCampos(){
    
    const correo= document.getElementById("correo_regis").value===null?"":document.getElementById("correo_regis").value;
    const nombre= document.getElementById("nombre").value===null?"":document.getElementById("nombre").value;
    const app= document.getElementById("apellidop").value===null?"":document.getElementById("apellidop").value;
    const apm= document.getElementById("apellidom").value===null?"":document.getElementById("apellidom").value;
    const contra= document.getElementById("contracon").value===document.getElementById("contrare").value;
    const enviar= document.getElementById("env_nue");
    const patcorreo=/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    const patnombre=/^([A-Z]{1}[a-z]{1,})$|^([A-Z]{1}[a-z]{1,}\040[A-Z]{1}[a-z]{1,})$|^([A-Z]{1}[a-z]{1,}\040[A-Z]{1}[a-z]{1,}\040[A-Z]{1}[a-z]{1,})$|^$/;
    
    if(patcorreo.test(correo) && patnombre.test(apm) 
            && patnombre.test(app) && patnombre.test(nombre) 
            && contra){
        enviar.disabled= false;
    }   else    {
        enviar.disabled= true;
    }
    
    
}

