/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Cita()
{
    var mes = document.getElementById('mes').value;
    var dia = new Date().getMonth();
    var meses30= ["Abril","Junio","Septiembre","Noviembre"];
    
    console.log(mes)
    
    if(meses30.indexOf(mes) !== -1) 
    {
        document.getElementById("31").style.display= 'none';
    } else 
    {
        document.getElementById("31").style.display= 'initial';
    }
    
}


