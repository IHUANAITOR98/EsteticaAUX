/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function displayMeses(){
    var meses = new Date().getMonth();
    var mesesdis= ["Enero", "Febrero", "Marzo","Abril",
                    "Mayo","Junio","Julio","Agosto","Septiembre",
                    "Octubre","Noviembre","Diciembre"];
                
    for(i= 0; i<mesesdis.length; i++){
        if(meses !== i){
            document.getElementById(mesesdis[i]).style.display= 'none';
        } else {
            break;
        }
    }
}

function Cita()
{
    var mes = document.getElementById('mes').value;
   
    var meses30= ["Abril","Junio","Septiembre","Noviembre"];
    
    excluirDias();
    
    if(meses30.indexOf(mes) !== -1) 
    {
        document.getElementById("31").style.display= 'none';
    } else 
    {
        document.getElementById("31").style.display= 'initial';
    }
    
    
}

function excluirDias(){
    
    var eleccion= document.getElementById('mes').value;
    var mes= new Date().getMonth();
    var dia= new Date().getDate();
    var meses= ['Enero','Febrero','Marzo','Abril',
                'Mayo','Junio','Julio','Agosto',
                'Septiembre','Ocutbre','Noviembre','Diciembre'];
    
    if(eleccion === meses[mes]){
        for(i=0; i<31; i++)
        {
            if (i!==dia)
            {
                document.getElementById(i+1).style.display='none';
            } else 
            {
                break;
            }
        }
    } else {
        for(i=0; i<31;i++)
        {
            document.getElementById(i+1).style.display='initial';
        }
    }
    
    
}


