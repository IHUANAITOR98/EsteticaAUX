/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function displayMeses(){
    var meses = new Date().getMonth();
    var mesesdis= ["Enero", "Febrero", "Marzo","Abril",
                    "Mayo","Junio","Julio","Agosto","Septiembre",
                    "Octubre","Noviembre","Diciembre"];
                
    for(i= 0; i<mesesdis.length; i++){
        if(meses !== i){
            document.getElementById(mesesdis[i]).style.display= 'none';
        } else {
            document.getElementById(mesesdis[i]).selected= 'selected';
            break;
        }
    }
}

function Cita()
{
    var mes = document.getElementById('mes').value;
   
    var meses30= ["Abril","Junio","Septiembre","Noviembre"];
    
    if(meses30.indexOf(mes) !== -1) 
    {
        document.getElementById("31").style.display= 'none';
    } else 
    {
        document.getElementById("31").style.display= 'initial';
    }
    
}


