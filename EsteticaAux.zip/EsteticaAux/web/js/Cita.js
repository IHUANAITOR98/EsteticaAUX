function displayMaquillaje(){
    const cuerpo=document.getElementById('cuerpomaquillaje');
    if(cuerpo.style.display === 'none'){
        cuerpo.style.display='initial';
    } else {
        cuerpo.style.display='none';
    }
}

function displayManos(){
    const cuerpo=document.getElementById('cuerpomanos');
    if(cuerpo.style.display === 'none'){
        cuerpo.style.display='initial';
    } else {
        cuerpo.style.display='none';
    }
}

function displayPeluqueria(){
    const cuerpo= document.getElementById('cuerpopeluqueria');
    if(cuerpo.style.display === 'none'){
        cuerpo.style.display='initial';
    } else {
        cuerpo.style.display='none';
    }
}    

