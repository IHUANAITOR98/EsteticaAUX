/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Compra {
    
    private int id_com;
    private String id_cit;
    private int id_cli;
    private int id_emp;
    private int id_ser;
    private int id_suc;

    public Compra(int id_com, String id_cit, int id_cli, int id_emp, int id_ser, int id_suc) {
        this.id_com = id_com;
        this.id_cit = id_cit;
        this.id_cli = id_cli;
        this.id_emp = id_emp;
        this.id_ser = id_ser;
        this.id_suc = id_suc;
    }

    public int getId_com() {
        return id_com;
    }

    public void setId_com(int id_com) {
        this.id_com = id_com;
    }

    public String getId_cit() {
        return id_cit;
    }

    public void setId_cit(String id_cit) {
        this.id_cit = id_cit;
    }

    public int getId_cli() {
        return id_cli;
    }

    public void setId_cli(int id_cli) {
        this.id_cli = id_cli;
    }

    public int getId_emp() {
        return id_emp;
    }

    public void setId_emp(int id_emp) {
        this.id_emp = id_emp;
    }

    public int getId_ser() {
        return id_ser;
    }

    public void setId_ser(int id_ser) {
        this.id_ser = id_ser;
    }

    public int getId_suc() {
        return id_suc;
    }

    public void setId_suc(int id_suc) {
        this.id_suc = id_suc;
    }
    
}
