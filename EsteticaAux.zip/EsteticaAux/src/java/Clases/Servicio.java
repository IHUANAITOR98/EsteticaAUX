/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Servicio {
    
    private int id_ser;
    private String nom_ser;
    private int dur_ser;
    private float cos_ser;

    public Servicio(int id_ser, String nom_ser, int dur_ser, float cos_ser) {
        this.id_ser = id_ser;
        this.nom_ser = nom_ser;
        this.dur_ser = dur_ser;
        this.cos_ser = cos_ser;
    }

    public int getId_ser() {
        return id_ser;
    }

    public void setId_ser(int id_ser) {
        this.id_ser = id_ser;
    }

    public String getNom_ser() {
        return nom_ser;
    }

    public void setNom_ser(String nom_ser) {
        this.nom_ser = nom_ser;
    }

    public int getDur_ser() {
        return dur_ser;
    }

    public void setDur_ser(int dur_ser) {
        this.dur_ser = dur_ser;
    }

    public float getCos_ser() {
        return cos_ser;
    }

    public void setCos_ser(float cos_ser) {
        this.cos_ser = cos_ser;
    }
    
    
}
