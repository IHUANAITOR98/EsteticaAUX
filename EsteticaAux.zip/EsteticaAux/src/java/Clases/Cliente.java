/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Cliente {
    
    private int id_cli;
    private String nom_cli;
    private String app_cli;
    private String apm_cli;
    private String mail_cli;
    private String con_cli;

    public Cliente(int id_cli, String nom_cli, String app_cli, 
                    String apm_cli, String mail_cli, String con_cli) {
        this.id_cli = id_cli;
        this.nom_cli = nom_cli;
        this.app_cli = app_cli;
        this.apm_cli = apm_cli;
        this.mail_cli = mail_cli;
    }

    public int getId_cli() {
        return id_cli;
    }

    public void setId_cli(int id_cli) {
        this.id_cli = id_cli;
    }

    public String getNom_cli() {
        return nom_cli;
    }

    public void setNom_cli(String nom_cli) {
        this.nom_cli = nom_cli;
    }

    public String getApp_cli() {
        return app_cli;
    }

    public void setApp_cli(String app_cli) {
        this.app_cli = app_cli;
    }

    public String getApm_cli() {
        return apm_cli;
    }

    public void setApm_cli(String apm_cli) {
        this.apm_cli = apm_cli;
    }

    public String getMail_cli() {
        return mail_cli;
    }

    public void setMail_cli(String mail_cli) {
        this.mail_cli = mail_cli;
    }
    
    public String getCon_cli() {
        return con_cli;
    }

    public void setCon_cli(String con_cli) {
        this.con_cli = con_cli;
    }
    
}
