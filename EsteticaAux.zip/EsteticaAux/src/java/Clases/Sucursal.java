/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Sucursal {
    
    private int id_suc;
    private String nom_suc;

    public Sucursal(int id_suc, String nom_suc) {
        this.id_suc = id_suc;
        this.nom_suc = nom_suc;
    }

    public int getId_suc() {
        return id_suc;
    }

    public void setId_suc(int id_suc) {
        this.id_suc = id_suc;
    }

    public String getNom_suc() {
        return nom_suc;
    }

    public void setNom_suc(String nom_suc) {
        this.nom_suc = nom_suc;
    }
    
    
    
}
