/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class TipoEmpleo {
    
    private int id_tpem;
    private String nom_tpem;

    public TipoEmpleo(int id_tpem, String nom_tpem) {
        this.id_tpem = id_tpem;
        this.nom_tpem = nom_tpem;
    }

    public int getId_tpem() {
        return id_tpem;
    }

    public void setId_tpem(int id_tpem) {
        this.id_tpem = id_tpem;
    }

    public String getNom_tpem() {
        return nom_tpem;
    }

    public void setNom_tpem(String nom_tpem) {
        this.nom_tpem = nom_tpem;
    }
    
}
