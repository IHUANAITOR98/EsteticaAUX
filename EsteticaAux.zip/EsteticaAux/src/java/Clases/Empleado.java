/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Empleado {
    
    private int id_emp;
    private String nom_emp;
    private String app_emp;
    private String apm_emp;

    public Empleado(int id_emp, String nom_emp, String app_emp, String apm_emp) {
        this.id_emp = id_emp;
        this.nom_emp = nom_emp;
        this.app_emp = app_emp;
        this.apm_emp = apm_emp;
    }

    public int getId_emp() {
        return id_emp;
    }

    public void setId_emp(int id_emp) {
        this.id_emp = id_emp;
    }

    public String getNom_emp() {
        return nom_emp;
    }

    public void setNom_emp(String nom_emp) {
        this.nom_emp = nom_emp;
    }

    public String getApp_emp() {
        return app_emp;
    }

    public void setApp_emp(String app_emp) {
        this.app_emp = app_emp;
    }

    public String getApm_emp() {
        return apm_emp;
    }

    public void setApm_emp(String apm_emp) {
        this.apm_emp = apm_emp;
    }
    
}
