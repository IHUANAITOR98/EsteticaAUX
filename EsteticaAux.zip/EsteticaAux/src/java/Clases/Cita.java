/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class Cita {
    
    private String id_cita;
    private int sta_cit;
    private String dia_cit;
    private float pago_cit;
    private float res_cit;
    private int dur_cit;

    public Cita(String id_cita, int sta_cit, String dia_cit, float pago_cit, float res_cit, int dur_cit) {
        this.id_cita = id_cita;
        this.sta_cit = sta_cit;
        this.dia_cit = dia_cit;
        this.pago_cit = pago_cit;
        this.res_cit = res_cit;
        this.dur_cit = dur_cit;
    }

    public String getId_cita() {
        return id_cita;
    }

    public void setId_cita(String id_cita) {
        this.id_cita = id_cita;
    }

    public int getSta_cit() {
        return sta_cit;
    }

    public void setSta_cit(int sta_cit) {
        this.sta_cit = sta_cit;
    }

    public String getDia_cit() {
        return dia_cit;
    }

    public void setDia_cit(String dia_cit) {
        this.dia_cit = dia_cit;
    }

    public float getPago_cit() {
        return pago_cit;
    }

    public void setPago_cit(float pago_cit) {
        this.pago_cit = pago_cit;
    }

    public float getRes_cit() {
        return res_cit;
    }

    public void setRes_cit(float res_cit) {
        this.res_cit = res_cit;
    }

    public int getDur_cit() {
        return dur_cit;
    }

    public void setDur_cit(int dur_cit) {
        this.dur_cit = dur_cit;
    }
    
    
    
}
