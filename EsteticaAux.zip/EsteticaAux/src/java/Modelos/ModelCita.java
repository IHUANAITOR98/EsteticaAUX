/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import Clases.Cita;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class ModelCita {
 
    public String showCitas(Cita cita){
        String html="";
        try {
            SimpleDateFormat formato= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date ini= formato.parse(cita.getDia_cit());
            Calendar calendario= Calendar.getInstance();
            calendario.setTime(ini);
            calendario.add(Calendar.MINUTE, cita.getDur_cit());
            Date acaba= calendario.getTime();
            html+="<tr>"
                    + "<td>"+cita.getId_cita()+"</td>"
                    + "<td>"+(cita.getDia_cit())+"</td>"
                    + "<td>"+Integer.toString(cita.getDur_cit())+"</td>"
                    + "<td>"+formato.format(acaba)+"</td>"
                  + "</tr>";
        } catch (ParseException ex) {
            ex.printStackTrace();
            System.err.println();
        }
        
        return html;
    }
    
    public String showCitasCliente(Cita cita){
        String html="";
        try {
            SimpleDateFormat formato= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date ini= formato.parse(cita.getDia_cit());
            Calendar calendario= Calendar.getInstance();
            calendario.setTime(ini);
            calendario.add(Calendar.MINUTE, cita.getDur_cit());
            Date acaba= calendario.getTime();
            html+="<tr>"
                    + "<td>"+cita.getId_cita()+"</td>"
                    + "<td>"+(cita.getDia_cit())+"</td>"
                    + "<td>"+Integer.toString(cita.getDur_cit())+"</td>"
                    + "<td>"+formato.format(acaba)+"</td>"
                  + "</tr>";
        } catch (ParseException ex) {
            ex.printStackTrace();
            System.err.println();
        }
        
        return html;
    }
    
}
