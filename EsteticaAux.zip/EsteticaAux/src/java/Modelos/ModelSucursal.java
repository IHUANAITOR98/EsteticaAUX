/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import Clases.Sucursal;
import Controladores.CSucursal;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class ModelSucursal {
    public String getSucursales(){
        ArrayList<Sucursal> sucursales= new CSucursal().getSucursales();
        String html="";
        for(Sucursal suc : sucursales){
            html+="<option values=\""+suc.getNom_suc()+"\">"
                    +suc.getNom_suc()
                    +"</option>";
        }
        
        return html;
    }
}
