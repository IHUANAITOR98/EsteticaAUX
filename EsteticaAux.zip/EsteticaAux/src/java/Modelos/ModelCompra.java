/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import Clases.Compra;
import Controladores.MCompra;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author USUARIO
 */
public class ModelCompra {
    
    public String getCompraSuc(String sucursal){
        String html="";
        ArrayList<Compra> compras= new MCompra().getCompras(sucursal);
        HashMap<String,Integer> conteo= new HashMap<>();
        for(Compra com : compras){
            if(conteo.containsKey(Integer.toString(com.getId_ser()))){
                conteo.put(Integer.toString(com.getId_ser())
                        ,conteo.get(Integer.toString(com.getId_ser()))+1);
            } else {
                conteo.put(Integer.toString(com.getId_ser())
                        , 1);
            }
        }
        for(String i : conteo.keySet()){
            html+="<tr>"
                    +"<td>"+i+"</td>"
                    +"<td>"+conteo.get(i).toString()+"</td>"
                  + "</tr>";
        }
        return html;
    }
    
}
