/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import Controladores.CServicios;
import Clases.Servicio;
import java.util.ArrayList;
        

/**
 *
 * @author USUARIO
 */
public class ModelServicio {
    
    public String getServicios(){
        String html="";
        ArrayList<Servicio> Servicios= new CServicios().getServicios();
        
        for(Servicio se : Servicios){
            html+="<tr>"+
                    "<td>"+
                        se.getNom_ser()+
                    "</td>"+
                    "<td>"+
                        se.getDur_ser()+
                    "</td>"+
                    "<td>"+
                        se.getCos_ser()+
                    "</td>"+
                  "</tr>";
        }
        
        return html;
    }
    
    public String getMaquillaje(){
        String html="";
        ArrayList<Servicio> servicios= new CServicios().getMaquillaje();
        for(Servicio ser : servicios){
            html+="<tr>"
                    +"<td>"+ser.getNom_ser()+"</td>"
                    +"<td>"+ser.getDur_ser()+"</td>"
                    +"<td>"+ser.getCos_ser()+"</td>"
                    +"<td><button>Agregar</button></td>"
                 + "</tr>";
        }
        
        return html;
    }
    
    public String getManos(){
        String html="";
        ArrayList<Servicio> servicios= new CServicios().getManos();
        for(Servicio ser : servicios){
            html+="<tr>"
                    +"<td>"+ser.getNom_ser()+"</td>"
                    +"<td>"+ser.getDur_ser()+"</td>"
                    +"<td>"+ser.getCos_ser()+"</td>"
                    +"<td><button>Agregar</button></td>"
                 + "</tr>";
        }
        
        return html;
    }
    
    public String getPeluqueria(){
        String html="";
        ArrayList<Servicio> servicios= new CServicios().getPeluqueria();
        for(Servicio ser : servicios){
            html+="<tr>"
                    +"<td>"+ser.getNom_ser()+"</td>"
                    +"<td>"+ser.getDur_ser()+"</td>"
                    +"<td>"+ser.getCos_ser()+"</td>"
                    +"<td><button>Agregar</button></td>"
                 + "</tr>";
        }
        
        return html;
    }
    
}
