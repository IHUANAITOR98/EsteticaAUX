/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Clases.Compra;
import Clases.Servicio;
import Controladores.CServicios;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "EliminarServicio", urlPatterns = {"/delsrvice"})
public class EliminarServicio extends HttpServlet {
    
    ///delsrvice

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String id_ser= request.getParameter("id_ser");
        ArrayList<Compra> carrito= (ArrayList<Compra>)request.getSession().getAttribute("carrito");
        ArrayList<Compra> newcarrito= new ArrayList();
        if (!carrito.isEmpty()){
            for(Compra com : carrito){
                if(String.valueOf(com.getId_ser()).equals(id_ser)){
                    continue;
                }
                newcarrito.add(com);
            }
            Servicio servicio= new CServicios().getServicio(id_ser);
            int duracion= request.getSession().getAttribute("duracion")==null?0:((int)request.getSession().getAttribute("duracion"));
            duracion -= servicio.getDur_ser();
            request.getSession().setAttribute("duracion", duracion);
            double costo= request.getSession().getAttribute("costo")==null?0:((double)request.getSession().getAttribute("costo"));
            costo-= servicio.getCos_ser();
            request.getSession().setAttribute("costo", costo);
            request.getSession().setAttribute("carrito", newcarrito);
        }
        request.getRequestDispatcher("/Cita.jsp").forward(request, response);
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
