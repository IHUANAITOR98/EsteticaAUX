/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Clases.Cliente;
import Clases.Compra;
import Clases.Servicio;
import Controladores.CServicios;
import Controladores.MClientes;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "AgregarServicio", urlPatterns = {"/addsrvice"})
public class AgregarServicio extends HttpServlet {
    
    //Instancia: /addsrvice

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public ArrayList<Compra> isNull(){
        ArrayList<Compra> carrito= new ArrayList<Compra>();
        return carrito;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

                
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        String id_ser= request.getParameter("id_ser");
        String sucursal= request.getParameter("sucursales");
        Cliente cliente= new MClientes().getCliente(request.getSession().getAttribute("nombre").toString());
        Servicio servicio= new CServicios().getServicio(id_ser);
        ArrayList<Compra> carrito= (ArrayList<Compra>)request.getSession().getAttribute("carrito")== null
                        ?isNull():(ArrayList<Compra>)request.getSession().getAttribute("carrito");
        carrito.add(new Compra(0,"",cliente.getId_cli(),0,Integer.parseInt(id_ser),0));
        /*
        double costo= (double)request.getSession().getAttribute("cos_total");
        request.getSession().setAttribute("cos_total", (double)servicio.getCos_ser()+costo);
        int duracion= request.getSession().getAttribute("dur_total")==null?0:(int)request.getSession().getAttribute("dur_total");
        request.getSession().setAttribute("cos_total", servicio.getDur_ser()+duracion);
        request.getSession().setAttribute("carrito", carrito);
        */
        request.getSession().setAttribute("carrito", carrito);
        int duracion= servicio.getDur_ser();
        duracion+= request.getSession().getAttribute("duracion")==null?0:((int)request.getSession().getAttribute("duracion"));
        request.getSession().setAttribute("duracion", duracion);
        double costo= servicio.getCos_ser();
        costo+=  request.getSession().getAttribute("costo")==null?0:((double)request.getSession().getAttribute("costo"));
        request.getSession().setAttribute("costo", costo);
        request.getRequestDispatcher("/Cita.jsp").forward(request, response);
        
        
        //out.print(carrito.get(0).getId_ser());
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
