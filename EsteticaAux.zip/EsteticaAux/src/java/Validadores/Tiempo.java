/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validadores;

import java.util.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class Tiempo {
    
    public boolean isDisponible(String cita, String previo, int dur, int durpre){
        
        boolean isDisponible=false;
        try {
            Date agendar= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(cita);
            Date agendada= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(previo);
            
            Calendar calendario= Calendar.getInstance();
            Calendar comparar= Calendar.getInstance();
            calendario.setTime(agendar);
            comparar.setTime(agendada);
            if(calendario.getTime().before(agendada)){
                System.out.println(calendario.getTime());
                System.out.println(agendada);
                calendario.add(Calendar.MINUTE, dur);
                if(calendario.getTime().before(agendada)){
                    System.out.println(calendario.getTime());
                    System.out.println(agendada);
                    isDisponible=true;
                }
            } else if(calendario.getTime().after(agendada)){
                System.out.println(calendario.getTime());
                System.out.println(comparar.getTime());
                comparar.add(Calendar.MINUTE, durpre);
                if(calendario.getTime().after(comparar.getTime())){
                    System.out.println(calendario.getTime());
                    System.out.println(comparar.getTime());
                    isDisponible=true;
                }
            } 
            
            
        } catch (ParseException ex) {
            System.err.println();
        }
        return isDisponible;
    }
    
    /*public static void main(String[] args) {
        System.out.println(isDisponible("2020-07-15 12:35:00", "2020-07-15 09:00:00", 20, 75));
        
    }*/
    
}
