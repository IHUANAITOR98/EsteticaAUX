/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Servicio;
import Conexion.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class CServicios {
    
    public ArrayList<Servicio> getServicios(){
        ArrayList<Servicio> Servicios = new ArrayList<>();
        Connection con= new Provider().getConnection();
        PreparedStatement ps= null;
        ResultSet rs= null;
        
        try{
            String sql= "CALL getServicios()";
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                Servicios.add(new Servicio(
                                rs.getInt("id_ser"),
                                rs.getString("nom_ser"),
                                rs.getInt("dur_ser"),
                                rs.getFloat("cos_ser")));
            }
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
                rs.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        
        return Servicios;
    }
    
    public ArrayList<Servicio> getMaquillaje(){
        
        ArrayList<Servicio> maquillaje= new ArrayList();
        Connection con= new Provider().getConnection();
        PreparedStatement ps= null;
        ResultSet rs= null;
        
        try{
            String sql= "SELECT id_ser, nom_ser, dur_ser, cos_ser FROM CServicios WHERE id_ser IN (1,2,3,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35)";
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                maquillaje.add(new Servicio(
                                rs.getInt("id_ser"),
                                rs.getString("nom_ser"),
                                rs.getInt("dur_ser"),
                                rs.getFloat("cos_ser")));
            }
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
                rs.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return maquillaje;
    }
    public ArrayList<Servicio> getManos(){
        
        ArrayList<Servicio> manos= new ArrayList();
        Connection con= new Provider().getConnection();
        PreparedStatement ps= null;
        ResultSet rs= null;
        
        try{
            String sql= "SELECT id_ser, nom_ser, dur_ser, cos_ser FROM CServicios WHERE id_ser IN (4,5,6,7,8,9,10,11,12,13,14,15,16,17,18)";
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                manos.add(new Servicio(
                                rs.getInt("id_ser"),
                                rs.getString("nom_ser"),
                                rs.getInt("dur_ser"),
                                rs.getFloat("cos_ser")));
            }
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
                rs.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return manos;
    }
    public ArrayList<Servicio> getPeluqueria(){
        
        ArrayList<Servicio> peluqueria= new ArrayList();
        Connection con= new Provider().getConnection();
        PreparedStatement ps= null;
        ResultSet rs= null;
        
        try{
            String sql= "SELECT id_ser, nom_ser, dur_ser, cos_ser FROM CServicios WHERE id_ser IN (36,37,38,39,40)";
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                peluqueria.add(new Servicio(
                                rs.getInt("id_ser"),
                                rs.getString("nom_ser"),
                                rs.getInt("dur_ser"),
                                rs.getFloat("cos_ser")));
            }
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
                rs.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return peluqueria;
    }
    
}
