/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Servicio;
import Conexion.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class CServicios {
    
    public ArrayList<Servicio> getServicios(){
        ArrayList<Servicio> Servicios = new ArrayList<>();
        Connection con= new Provider().getConnection();
        PreparedStatement ps= null;
        ResultSet rs= null;
        
        try{
            String sql= "CALL getServicios()";
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                Servicios.add(new Servicio(
                                rs.getInt("id_ser"),
                                rs.getString("nom_ser"),
                                rs.getInt("dur_ser"),
                                rs.getFloat("cos_ser")));
            }
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
                rs.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        
        return Servicios;
    }
    
}
