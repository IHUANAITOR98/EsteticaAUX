/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Servicio;
import Conexion.Provider;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import javafx.animation.KeyValue;

/**
 *
 * @author USUARIO
 */
public class MClientes {
    
    public  int isCliente(String correo, String contra){
        int res= 0;
        CallableStatement cl= null;
        Connection con = new Provider().getConnection();
        try{
            String sql= "CALL isCliente('"+correo+
                    "','"+contra+"', ?)";
            cl= con.prepareCall(sql);
            cl.registerOutParameter(1, Types.INTEGER);
            cl.execute();
            res= cl.getInt(1);
            
        }catch(SQLException e){
            System.out.println("Error en la BD");
            e.printStackTrace();
            System.err.println();
        }catch(Exception ex){
            System.out.println("Error general");
            ex.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                cl.close();
            }catch(SQLException se){
                System.out.println("Error al cerrar conexion");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        return res;
    }
    
}
