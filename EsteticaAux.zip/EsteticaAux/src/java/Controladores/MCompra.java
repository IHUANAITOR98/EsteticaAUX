/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Conexion.Provider;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author USUARIO
 */
public class MCompra {
    
    public void doCompra(String cita, int cli, int emp, int ser, int suc){
        CallableStatement cs= null;
        Connection con = new Provider().getConnection();
        
        try{
            
            String sql= "CALL isAdmin(?,?,?,?,?)";
            cs= con.prepareCall(sql);
            cs.setString(1, cita);
            cs.setInt(2, cli);
            cs.setInt(3, emp);
            cs.setInt(4, ser);
            cs.setInt(5, suc);
            cs.execute();
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        } finally{
            try{
                con.close();
                cs.close();
            } catch(SQLException se){
                System.out.println("Error al cerrar conexiones");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        
    }
    
}
