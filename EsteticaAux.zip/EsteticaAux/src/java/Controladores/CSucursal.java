/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Sucursal;
import Conexion.Provider;
import java.sql.CallableStatement;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;


/**
 *
 * @author USUARIO
 */
public class CSucursal {
    
    public int isSucursal( String id_suc){
        int isSucursal= 0;
        CallableStatement ps= null;
        Connection con= new Provider().getConnection();
        try{
            
            String sql= "CALL isSucursal("+id_suc+", ?)";
            ps= con.prepareCall(sql);
            ps.registerOutParameter(1, Types.INTEGER);
            ps.execute();
            isSucursal= ps.getInt(1);
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
            }catch(SQLException se){
                System.out.println("Error en la BD");
                se.printStackTrace();
                System.err.println();
            }catch(Exception e){
                System.out.println("Error general");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return isSucursal;
    }
    
    public ArrayList<Sucursal> getSucursales(){
        ArrayList<Sucursal> sucursales= new ArrayList();
        PreparedStatement ps= null;
        ResultSet rs= null;
        Connection con= new Provider().getConnection();
        try{
            
            String sql= "Select * FROM CSucursal";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                sucursales.add(
                        new Sucursal(
                              rs.getInt("id_suc"),
                              rs.getString("nom_suc")
                        )
                );
            }
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        }finally{
            try{
                con.close();
                ps.close();
            }catch(SQLException se){
                System.out.println("Error en la BD");
                se.printStackTrace();
                System.err.println();
            }catch(Exception e){
                System.out.println("Error general");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return sucursales;
    }
    
    
}
