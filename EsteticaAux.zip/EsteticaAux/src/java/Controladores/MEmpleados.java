/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Empleado;
import Conexion.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author USUARIO
 */
public class MEmpleados {
    
    public Empleado getEmpleado(String id_emp){
        
        Empleado emp= null;
        PreparedStatement ps= null;
        ResultSet rs= null;
        Connection con= new Provider().getConnection();
        
        try{
            
            String sql= "SELECT * FROM MEmpleados WHERE id_emp="+id_emp;
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            
            while(rs.next()){
                emp= new Empleado(rs.getInt("id_emp"),
                                rs.getString("nom_emp"),
                                rs.getString("app_emp"),
                                rs.getString("apm_emp"));
            }
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        } finally{
            try{
                con.close();
                ps.close();
                rs.close();
            } catch(SQLException se){
                System.out.println("Error al cerrar conexiones");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return emp;
    }
    
}
