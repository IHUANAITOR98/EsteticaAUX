/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Cita;
import Conexion.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class DCita {
    
    public ArrayList<Cita> getCitas(){
        ArrayList<Cita> citas= new ArrayList<>();
        PreparedStatement ps= null;
        ResultSet rs= null;
        Connection con= new Provider().getConnection();
        try{
            
            String sql= "SELECT id_cita, dia_cit, dur_cia"
                    + "     FROM DCita WHERE sta_cit=1";
            ps= con.prepareStatement(sql);
            ps.execute();
            rs= ps.executeQuery();
            while(rs.next()){
            
            }
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        } finally{
            try{
                con.close();
                ps.close();
            } catch(SQLException se){
                System.out.println("Error al cerrar conexiones");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        
        return citas;
    }
    
}
