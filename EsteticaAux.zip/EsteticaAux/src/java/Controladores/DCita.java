/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Clases.Cita;
import Conexion.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author USUARIO
 */
public class DCita {
    
    public HashMap<String, ArrayList<Cita> > getCitas(String sucursal){

        HashMap<String, ArrayList<Cita> > citas= new HashMap();
        ArrayList<Cita> cita= new ArrayList();
        SimpleDateFormat formato= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date ahora= new Date();
        PreparedStatement ps= null;
        ResultSet rs= null;
        Connection con= new Provider().getConnection();
        try{
            
            String sql= "SELECT DISTINCT DCita.id_cita, DCita.dia_cit, DCita.dur_cit, "
                    + "DCita.pago_cit, DCita.res_cit "
                    + "FROM DCita "
                    + "INNER JOIN MCompra "
                    + "ON DCita.id_cita=MCompra.id_cita "
                    + "WHERE DCita.sta_cit=1 "
                    + "AND DCita.dia_cit >= STR_TO_DATE(\'"+ formato.format(ahora)+"\', \'%Y-%m-%d %H:%i:%s\') "
                    + "AND MCompra.id_suc= "
                    + "(SELECT id_suc FROM CSucursal WHERE nom_suc=\'"+sucursal+"\')";
            System.out.println(sql);
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                cita.add( new Cita(
                                    rs.getString("id_cita"),
                                    1,
                                    rs.getTimestamp("dia_cit").toString(),
                                    rs.getFloat("pago_cit"),
                                    rs.getFloat("res_cit"),
                                    rs.getInt("dur_cit")));
            }
            citas.put(sucursal, cita);
            
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        } finally{
            try{
                con.close();
                ps.close();
            } catch(SQLException se){
                System.out.println("Error al cerrar conexiones");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return citas;
    }
    
    public HashMap<String, ArrayList<Cita> > getCitasSucursal(String sucursal){

        HashMap<String, ArrayList<Cita> > citas= new HashMap();
        ArrayList<Cita> cita= new ArrayList();
        SimpleDateFormat formato= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date ahora= new Date();
        PreparedStatement ps= null;
        ResultSet rs= null;
        Connection con= new Provider().getConnection();
        try{
            
            String sql= "SELECT DISTINCT DCita.id_cita, DCita.dia_cit, DCita.dur_cit, "
                    + "DCita.pago_cit, DCita.res_cit "
                    + "FROM DCita "
                    + "INNER JOIN MCompra "
                    + "ON DCita.id_cita=MCompra.id_cita "
                    + "WHERE DCita.sta_cit=1 "
                    + "AND DCita.dia_cit >= STR_TO_DATE(\'"+ formato.format(ahora)+"\', \'%Y-%m-%d %H:%i:%s\') "
                    + "AND MCompra.id_suc="+sucursal;
            System.out.println(sql);
            ps= con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                cita.add( new Cita(
                                    rs.getString("id_cita"),
                                    1,
                                    rs.getTimestamp("dia_cit").toString(),
                                    rs.getFloat("pago_cit"),
                                    rs.getFloat("res_cit"),
                                    rs.getInt("dur_cit")));
            }
            citas.put(sucursal, cita);
            
            
        }catch(SQLException se){
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(Exception e){
            System.out.println("Error general");
            e.printStackTrace();
            System.err.println();
        } finally{
            try{
                con.close();
                ps.close();
            } catch(SQLException se){
                System.out.println("Error al cerrar conexiones");
                se.printStackTrace();
                System.err.println();
            } catch(Exception e){
                System.out.println("Error general al cerrar conexiones");
                e.printStackTrace();
                System.err.println();
            }
        }
        
        return citas;
    }
    
}
