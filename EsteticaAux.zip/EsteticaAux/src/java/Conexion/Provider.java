/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author USUARIO
 */
public class Provider {
    
    String URL="jdbc:mysql://localhost:3306/db_EstAUX";
    String DRIVER= "com.mysql.jdbc.Driver";
    String USER= "SaidsonG";
    String PASSWORD= "Dingoling0983";
    
    public Connection getConnection(){
        
        Connection Conexion= null;
        try{
            Class.forName(DRIVER);
            Conexion= DriverManager.getConnection(URL, USER, PASSWORD);
        }catch(SQLException se)
        {
            System.out.println("Error en la BD");
            se.printStackTrace();
            System.err.println();
        }catch(ClassNotFoundException ce)
        {
            System.out.println("Error con el Driver");
            ce.printStackTrace();
            System.err.println();
        }
        return Conexion;
    }
    
}
